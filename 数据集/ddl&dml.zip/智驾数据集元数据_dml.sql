-- ============================================================
-- 智驾数据集元数据库 DML（示例数据）
-- 依赖：先执行 智驾数据集元数据_ddl.sql
-- 说明：数据均为虚构；哈希值用 SHA2() 生成，格式为 sha256:<64位十六进制>
--       统计类字段（clip_count、ref_count 等）在文末由 SQL 根据关系表回填，保证一致
-- ============================================================

SET NAMES utf8mb4;
USE ad_dataset_meta;
SET SESSION group_concat_max_len = 1000000;

-- ------------------------------------------------------------
-- 1. dataset
-- ------------------------------------------------------------
INSERT INTO dataset (id, name, biz_domain, description, owner, security_level, acl_group, status, created_by) VALUES
(1, 'urban_noa_perception',   '感知', '城区 NOA 感知模型训练数据集（雨夜、cut-in 等场景）', 'zhang.san', 2, 'grp_perception', 1, 'zhang.san'),
(2, 'highway_pilot_prediction','预测', '高速领航轨迹预测数据集',                          'li.si',     2, 'grp_prediction', 1, 'li.si'),
(3, 'parking_slot_perception', '感知', '泊车车位感知数据集',                              'wang.wu',   1, 'grp_parking',    1, 'wang.wu');

-- ------------------------------------------------------------
-- 2. annotation_set
-- ------------------------------------------------------------
INSERT INTO annotation_set
(id, name, ann_type, method, producer, schema_ver, clip_count, qc_pass_rate, oss_path, content_hash, hash_detail_path, status, parent_id, created_at, created_by) VALUES
(1, 'ann_3d_box_v4',      '3d_box',     'mixed',  '自动标注模型 autolabel-v2 + 标注团队A', 'schema_1.3', 8, 96.40, 'oss://ad-data/annotations/ann_3d_box_v4/',      CONCAT('sha256:', SHA2('ann_3d_box_v4', 256)),      'oss://ad-data/annotations/ann_3d_box_v4/_hash_detail.json',      'released', NULL, '2026-08-15 10:00:00', 'label.bot'),
(2, 'ann_3d_box_v5',      '3d_box',     'mixed',  '自动标注模型 autolabel-v3 + 标注团队A', 'schema_1.3', 9, 98.70, 'oss://ad-data/annotations/ann_3d_box_v5/',      CONCAT('sha256:', SHA2('ann_3d_box_v5', 256)),      'oss://ad-data/annotations/ann_3d_box_v5/_hash_detail.json',      'released', 1,    '2026-09-22 16:00:00', 'label.bot'),
(3, 'ann_lane_v2',        'lane',       'auto',   '车道线模型 lane-net-v2',                'schema_1.1', 6, 94.10, 'oss://ad-data/annotations/ann_lane_v2/',        CONCAT('sha256:', SHA2('ann_lane_v2', 256)),        'oss://ad-data/annotations/ann_lane_v2/_hash_detail.json',        'draft',    NULL, '2026-09-28 11:00:00', 'label.bot'),
(4, 'ann_trajectory_v1',  'trajectory', 'auto',   '轨迹真值生成 traj-gen v1',              'schema_1.0', 2, 99.00, 'oss://ad-data/annotations/ann_trajectory_v1/',  CONCAT('sha256:', SHA2('ann_trajectory_v1', 256)),  'oss://ad-data/annotations/ann_trajectory_v1/_hash_detail.json',  'released', NULL, '2026-09-29 09:30:00', 'label.bot'),
(5, 'ann_parking_slot_v1','seg',        'manual', '标注团队B',                             'schema_1.0', 1, 97.50, 'oss://ad-data/annotations/ann_parking_slot_v1/', CONCAT('sha256:', SHA2('ann_parking_slot_v1', 256)), 'oss://ad-data/annotations/ann_parking_slot_v1/_hash_detail.json', 'draft', NULL, '2026-10-07 15:00:00', 'label.bot');

-- ------------------------------------------------------------
-- 3. dataset_version（统计字段先置 0，文末回填）
-- ------------------------------------------------------------
INSERT INTO dataset_version
(id, dataset_id, version, major, minor, patch, parent_version_id, status, deprecate_reason,
 annotation_set_id, calibration_policy, filter_rule, tag_distribution,
 manifest_path, manifest_hash, released_at, released_by, created_at, created_by) VALUES
(1, 1, 'v2.2.0', 2, 2, 0, NULL, 'released', NULL,
 1, 'calib_v2',
 'scene_tag IN (''夜间'',''雨天'') AND qc_pass = true',
 '{"夜间":0.50,"雨天":0.50,"隧道":0.17}',
 'oss://ad-data/manifests/urban_noa_perception/v2.2.0.manifest',
 CONCAT('sha256:', SHA2('manifest:urban_noa_perception:v2.2.0', 256)),
 '2026-08-21 10:00:00', 'zhang.san', '2026-08-20 10:00:00', 'zhang.san'),
(2, 1, 'v2.3.0', 2, 3, 0, 1, 'deprecated',
 'veh07 标定 calib_v2 错误，由 v2.3.1 替代',
 1, 'calib_v2',
 'scene_tag IN (''夜间'',''雨天'') AND event = ''cut-in'' AND qc_pass = true',
 '{"夜间":0.50,"雨天":0.38,"隧道":0.13}',
 'oss://ad-data/manifests/urban_noa_perception/v2.3.0.manifest',
 CONCAT('sha256:', SHA2('manifest:urban_noa_perception:v2.3.0', 256)),
 '2026-09-25 18:00:00', 'zhang.san', '2026-09-25 10:12:00', 'zhang.san'),
(3, 1, 'v2.3.1', 2, 3, 1, 2, 'released', NULL,
 2, 'calib_v3',
 'scene_tag IN (''夜间'',''雨天'') AND event = ''cut-in'' AND qc_pass = true',
 '{"夜间":0.56,"雨天":0.44,"隧道":0.11}',
 'oss://ad-data/manifests/urban_noa_perception/v2.3.1.manifest',
 CONCAT('sha256:', SHA2('manifest:urban_noa_perception:v2.3.1', 256)),
 '2026-10-03 10:00:00', 'zhang.san', '2026-10-02 15:30:00', 'zhang.san'),
(4, 1, 'v2.4.0', 2, 4, 0, 3, 'draft', NULL,
 2, 'calib_v3',
 'scene_tag IN (''夜间'',''雨天'',''隧道'') AND qc_pass = true',
 NULL,
 'oss://ad-data/manifests/urban_noa_perception/v2.4.0.manifest',
 CONCAT('sha256:', SHA2('manifest:urban_noa_perception:v2.4.0', 256)),
 NULL, NULL, '2026-10-09 11:00:00', 'zhang.san'),
(5, 2, 'v1.0.0', 1, 0, 0, NULL, 'released', NULL,
 4, 'calib_v1',
 'road_type = ''highway'' AND qc_pass = true',
 '{"白天":0.50,"夜间":0.50}',
 'oss://ad-data/manifests/highway_pilot_prediction/v1.0.0.manifest',
 CONCAT('sha256:', SHA2('manifest:highway_pilot_prediction:v1.0.0', 256)),
 '2026-10-01 09:30:00', 'li.si', '2026-09-30 09:00:00', 'li.si'),
(6, 3, 'v0.1.0', 0, 1, 0, NULL, 'draft', NULL,
 5, 'calib_v1',
 'scene = ''parking'' AND qc_pass = true',
 NULL,
 'oss://ad-data/manifests/parking_slot_perception/v0.1.0.manifest',
 CONCAT('sha256:', SHA2('manifest:parking_slot_perception:v0.1.0', 256)),
 NULL, NULL, '2026-10-08 14:00:00', 'wang.wu');

-- ------------------------------------------------------------
-- 4. clip
-- ------------------------------------------------------------
INSERT INTO clip
(clip_id, vehicle_id, collect_date, city, start_ts, end_ts, duration_sec, raw_package_id, raw_offset_ms,
 data_format, oss_path, size_bytes, file_count, clip_hash, hash_detail_path,
 desensitized, qc_status, storage_tier, created_at, created_by) VALUES
('clip_20260918_veh07_0032','veh07','2026-09-18','上海',
 UNIX_TIMESTAMP('2026-09-18 21:30:45')*1000, UNIX_TIMESTAMP('2026-09-18 21:31:05')*1000, 20,
 'drive_20260918_213045', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260918_veh07_0032/', 2150000000, 214,
 CONCAT('sha256:', SHA2('clip_20260918_veh07_0032',256)),
 'oss://ad-data/clips/clip_20260918_veh07_0032/_hash_detail.json', 1, 'pass', 'standard', '2026-09-19 03:00:00', 'ingest.bot'),
('clip_20260918_veh07_0045','veh07','2026-09-18','上海',
 UNIX_TIMESTAMP('2026-09-18 21:48:10')*1000, UNIX_TIMESTAMP('2026-09-18 21:48:30')*1000, 20,
 'drive_20260918_213045', 1045000, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260918_veh07_0045/', 2080000000, 212,
 CONCAT('sha256:', SHA2('clip_20260918_veh07_0045',256)),
 'oss://ad-data/clips/clip_20260918_veh07_0045/_hash_detail.json', 1, 'pass', 'standard', '2026-09-19 03:05:00', 'ingest.bot'),
('clip_20260919_veh07_0011','veh07','2026-09-19','上海',
 UNIX_TIMESTAMP('2026-09-19 22:05:30')*1000, UNIX_TIMESTAMP('2026-09-19 22:05:50')*1000, 20,
 'drive_20260919_220530', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260919_veh07_0011/', 2210000000, 216,
 CONCAT('sha256:', SHA2('clip_20260919_veh07_0011',256)),
 'oss://ad-data/clips/clip_20260919_veh07_0011/_hash_detail.json', 1, 'pass', 'standard', '2026-09-20 03:00:00', 'ingest.bot'),
('clip_20260919_veh07_0087','veh07','2026-09-19','上海',
 UNIX_TIMESTAMP('2026-09-19 22:41:12')*1000, UNIX_TIMESTAMP('2026-09-19 22:41:37')*1000, 25,
 'drive_20260919_220530', 2142000, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260919_veh07_0087/', 2680000000, 262,
 CONCAT('sha256:', SHA2('clip_20260919_veh07_0087',256)),
 'oss://ad-data/clips/clip_20260919_veh07_0087/_hash_detail.json', 1, 'pass', 'standard', '2026-09-20 03:05:00', 'ingest.bot'),
('clip_20260920_veh08_0003','veh08','2026-09-20','上海',
 UNIX_TIMESTAMP('2026-09-20 09:12:00')*1000, UNIX_TIMESTAMP('2026-09-20 09:12:20')*1000, 20,
 'drive_20260920_091200', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260920_veh08_0003/', 2020000000, 210,
 CONCAT('sha256:', SHA2('clip_20260920_veh08_0003',256)),
 'oss://ad-data/clips/clip_20260920_veh08_0003/_hash_detail.json', 1, 'pass', 'standard', '2026-09-21 03:00:00', 'ingest.bot'),
('clip_20260920_veh08_0019','veh08','2026-09-20','苏州',
 UNIX_TIMESTAMP('2026-09-20 20:15:40')*1000, UNIX_TIMESTAMP('2026-09-20 20:16:00')*1000, 20,
 'drive_20260920_201540', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260920_veh08_0019/', 2190000000, 215,
 CONCAT('sha256:', SHA2('clip_20260920_veh08_0019',256)),
 'oss://ad-data/clips/clip_20260920_veh08_0019/_hash_detail.json', 1, 'pass', 'standard', '2026-09-21 03:05:00', 'ingest.bot'),
('clip_20260921_veh08_0054','veh08','2026-09-21','苏州',
 UNIX_TIMESTAMP('2026-09-21 10:22:05')*1000, UNIX_TIMESTAMP('2026-09-21 10:22:25')*1000, 20,
 'drive_20260921_102205', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260921_veh08_0054/', 1980000000, 208,
 CONCAT('sha256:', SHA2('clip_20260921_veh08_0054',256)),
 'oss://ad-data/clips/clip_20260921_veh08_0054/_hash_detail.json', 1, 'pass', 'standard', '2026-09-22 03:00:00', 'ingest.bot'),
('clip_20260921_veh08_0072','veh08','2026-09-21','苏州',
 UNIX_TIMESTAMP('2026-09-21 21:40:00')*1000, UNIX_TIMESTAMP('2026-09-21 21:40:30')*1000, 30,
 'drive_20260921_214000', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260921_veh08_0072/', 3120000000, 318,
 CONCAT('sha256:', SHA2('clip_20260921_veh08_0072',256)),
 'oss://ad-data/clips/clip_20260921_veh08_0072/_hash_detail.json', 1, 'pass', 'standard', '2026-09-22 03:05:00', 'ingest.bot'),
('clip_20260925_veh07_0008','veh07','2026-09-25','上海',
 UNIX_TIMESTAMP('2026-09-25 22:10:15')*1000, UNIX_TIMESTAMP('2026-09-25 22:10:35')*1000, 20,
 'drive_20260925_221015', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260925_veh07_0008/', 2240000000, 217,
 CONCAT('sha256:', SHA2('clip_20260925_veh07_0008',256)),
 'oss://ad-data/clips/clip_20260925_veh07_0008/_hash_detail.json', 1, 'pass', 'standard', '2026-09-26 03:00:00', 'ingest.bot'),
('clip_20260926_veh09_0021','veh09','2026-09-26','杭州',
 UNIX_TIMESTAMP('2026-09-26 14:05:00')*1000, UNIX_TIMESTAMP('2026-09-26 14:05:20')*1000, 20,
 'drive_20260926_140500', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260926_veh09_0021/', 1890000000, 205,
 CONCAT('sha256:', SHA2('clip_20260926_veh09_0021',256)),
 'oss://ad-data/clips/clip_20260926_veh09_0021/_hash_detail.json', 1, 'pass', 'standard', '2026-09-27 03:00:00', 'ingest.bot'),
('clip_20260927_veh09_0040','veh09','2026-09-27','杭州',
 UNIX_TIMESTAMP('2026-09-27 09:15:00')*1000, UNIX_TIMESTAMP('2026-09-27 09:15:20')*1000, 20,
 'drive_20260927_091500', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260927_veh09_0040/', 1950000000, 207,
 CONCAT('sha256:', SHA2('clip_20260927_veh09_0040',256)),
 'oss://ad-data/clips/clip_20260927_veh09_0040/_hash_detail.json', 1, 'pass', 'standard', '2026-09-28 03:00:00', 'ingest.bot'),
('clip_20260927_veh09_0066','veh09','2026-09-27','杭州',
 UNIX_TIMESTAMP('2026-09-27 19:30:00')*1000, UNIX_TIMESTAMP('2026-09-27 19:30:15')*1000, 15,
 'drive_20260927_193000', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260927_veh09_0066/', 1480000000, 160,
 CONCAT('sha256:', SHA2('clip_20260927_veh09_0066',256)),
 'oss://ad-data/clips/clip_20260927_veh09_0066/_hash_detail.json', 1, 'pass', 'standard', '2026-09-28 03:05:00', 'ingest.bot'),
('clip_20260605_veh05_0100','veh05','2026-06-05','上海',
 UNIX_TIMESTAMP('2026-06-05 11:00:00')*1000, UNIX_TIMESTAMP('2026-06-05 11:00:20')*1000, 20,
 'drive_20260605_110000', 0, 'mp4+pcd+parquet',
 'oss://ad-data/clips/clip_20260605_veh05_0100/', 1920000000, 206,
 CONCAT('sha256:', SHA2('clip_20260605_veh05_0100',256)),
 'oss://ad-data/clips/clip_20260605_veh05_0100/_hash_detail.json', 1, 'pass', 'standard', '2026-06-06 03:00:00', 'ingest.bot');

-- ------------------------------------------------------------
-- 5. tag_dict
-- ------------------------------------------------------------
INSERT INTO tag_dict (id, category, tag_name, description) VALUES
(1,  '天气', '雨天',       '降雨天气'),
(2,  '天气', '晴天',       '晴朗天气'),
(3,  '光照', '夜间',       '夜间行驶'),
(4,  '光照', '白天',       '白天行驶'),
(5,  '道路', '隧道',       '隧道内行驶'),
(6,  '道路', '施工区',     '道路施工区域'),
(7,  '事件', 'cut-in',     '旁车切入'),
(8,  '事件', '无保护左转', '无保护左转场景'),
(9,  '事件', '行人横穿',   '行人横穿马路'),
(10, '事件', '急刹',       '前方急刹或本车急刹');

-- ------------------------------------------------------------
-- 6. clip_tag
-- ------------------------------------------------------------
INSERT INTO clip_tag (clip_id, tag_id, source, source_ver, confidence, start_ms, end_ms) VALUES
('clip_20260918_veh07_0032', 1, 'rule',   'weather-rule-v1', 1.000, NULL, NULL),
('clip_20260918_veh07_0032', 3, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260918_veh07_0032', 7, 'model',  'event-net-v3',    0.930, 8200, 11500),
('clip_20260918_veh07_0045', 1, 'rule',   'weather-rule-v1', 1.000, NULL, NULL),
('clip_20260918_veh07_0045', 3, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260919_veh07_0011', 3, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260919_veh07_0011', 5, 'rule',   'road-rule-v1',    1.000, NULL, NULL),
('clip_20260919_veh07_0011', 7, 'model',  'event-net-v3',    0.880, 5000, 8000),
('clip_20260919_veh07_0087', 1, 'rule',   'weather-rule-v1', 1.000, NULL, NULL),
('clip_20260919_veh07_0087', 9, 'model',  'event-net-v3',    0.910, 12000, 15500),
('clip_20260920_veh08_0003', 2, 'rule',   'weather-rule-v1', 1.000, NULL, NULL),
('clip_20260920_veh08_0003', 4, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260920_veh08_0003', 8, 'model',  'event-net-v3',    0.950, 6000, 14000),
('clip_20260920_veh08_0019', 1, 'rule',   'weather-rule-v1', 1.000, NULL, NULL),
('clip_20260920_veh08_0019', 3, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260920_veh08_0019', 7, 'model',  'event-net-v3',    0.900, 9000, 12000),
('clip_20260920_veh08_0019', 7, 'manual', NULL,              1.000, 9100, 12000),
('clip_20260921_veh08_0054', 4, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260921_veh08_0054', 6, 'model',  'road-net-v2',     0.870, NULL, NULL),
('clip_20260921_veh08_0072', 3, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260921_veh08_0072', 5, 'rule',   'road-rule-v1',    1.000, NULL, NULL),
('clip_20260925_veh07_0008', 1, 'rule',   'weather-rule-v1', 1.000, NULL, NULL),
('clip_20260925_veh07_0008', 3, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260925_veh07_0008', 7, 'model',  'event-net-v3',    0.970, 7000, 10500),
('clip_20260925_veh07_0008',10, 'model',  'event-net-v3',    0.920, 10500, 12000),
('clip_20260926_veh09_0021', 4, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260926_veh09_0021', 8, 'model',  'event-net-v3',    0.890, 4000, 11000),
('clip_20260927_veh09_0040', 2, 'rule',   'weather-rule-v1', 1.000, NULL, NULL),
('clip_20260927_veh09_0040', 4, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260927_veh09_0066', 3, 'rule',   'light-rule-v1',   1.000, NULL, NULL),
('clip_20260605_veh05_0100', 2, 'rule',   'weather-rule-v1', 1.000, NULL, NULL),
('clip_20260605_veh05_0100', 4, 'rule',   'light-rule-v1',   1.000, NULL, NULL);

-- ------------------------------------------------------------
-- 7. calibration
-- ------------------------------------------------------------
INSERT INTO calibration
(id, vehicle_id, calib_version, valid_from, valid_to, sensor_scope, quality_score, oss_path, file_hash, status, invalid_reason, created_at, created_by) VALUES
(1, 'veh07', 'calib_v2', '2026-07-01 00:00:00', '2026-08-31 23:59:59', '7 路相机+前向激光雷达', 91.50,
 'oss://ad-data/calibration/veh07/2026-07/calib_v2.yaml', CONCAT('sha256:', SHA2('veh07:calib_v2',256)), 'valid', NULL, '2026-07-01 08:00:00', 'calib.bot'),
(2, 'veh07', 'calib_v3', '2026-09-01 00:00:00', NULL, '7 路相机+前向激光雷达', 96.80,
 'oss://ad-data/calibration/veh07/2026-09/calib_v3.yaml', CONCAT('sha256:', SHA2('veh07:calib_v3',256)), 'valid', NULL, '2026-09-01 08:00:00', 'calib.bot'),
(3, 'veh08', 'calib_v1', '2026-07-01 00:00:00', '2026-09-14 23:59:59', '7 路相机+前向激光雷达', 88.20,
 'oss://ad-data/calibration/veh08/2026-07/calib_v1.yaml', CONCAT('sha256:', SHA2('veh08:calib_v1',256)), 'invalid', '外参漂移，复检发现重投影误差超限', '2026-07-01 08:00:00', 'calib.bot'),
(4, 'veh08', 'calib_v2', '2026-09-15 00:00:00', NULL, '7 路相机+前向激光雷达', 95.30,
 'oss://ad-data/calibration/veh08/2026-09/calib_v2.yaml', CONCAT('sha256:', SHA2('veh08:calib_v2',256)), 'valid', NULL, '2026-09-15 08:00:00', 'calib.bot'),
(5, 'veh09', 'calib_v1', '2026-09-01 00:00:00', NULL, '6 路相机+毫米波雷达', 94.00,
 'oss://ad-data/calibration/veh09/2026-09/calib_v1.yaml', CONCAT('sha256:', SHA2('veh09:calib_v1',256)), 'valid', NULL, '2026-09-01 09:00:00', 'calib.bot');

-- ------------------------------------------------------------
-- 8. version_clip（split_type：1 train / 2 val / 3 test）
-- ------------------------------------------------------------
INSERT INTO version_clip (version_id, clip_id, split_type, shard_no, weight) VALUES
-- v2.2.0
(1, 'clip_20260918_veh07_0032', 1, 1, 1.5),
(1, 'clip_20260918_veh07_0045', 1, 1, 1.0),
(1, 'clip_20260919_veh07_0011', 1, 1, 1.0),
(1, 'clip_20260919_veh07_0087', 1, 2, 1.0),
(1, 'clip_20260920_veh08_0003', 2, 2, 1.0),
(1, 'clip_20260920_veh08_0019', 3, 2, 1.5),
-- v2.3.0（已作废）
(2, 'clip_20260918_veh07_0032', 1, 1, 1.5),
(2, 'clip_20260918_veh07_0045', 1, 1, 1.0),
(2, 'clip_20260919_veh07_0011', 1, 1, 1.0),
(2, 'clip_20260919_veh07_0087', 1, 1, 1.0),
(2, 'clip_20260920_veh08_0003', 1, 2, 1.0),
(2, 'clip_20260920_veh08_0019', 1, 2, 1.5),
(2, 'clip_20260921_veh08_0054', 2, 2, 1.0),
(2, 'clip_20260921_veh08_0072', 3, 2, 1.0),
-- v2.3.1
(3, 'clip_20260918_veh07_0032', 1, 1, 1.5),
(3, 'clip_20260918_veh07_0045', 1, 1, 1.0),
(3, 'clip_20260919_veh07_0011', 1, 1, 1.0),
(3, 'clip_20260919_veh07_0087', 1, 1, 1.0),
(3, 'clip_20260920_veh08_0003', 1, 2, 1.0),
(3, 'clip_20260920_veh08_0019', 1, 2, 1.5),
(3, 'clip_20260921_veh08_0072', 2, 2, 1.0),
(3, 'clip_20260925_veh07_0008', 3, 2, 1.5),
-- v2.4.0（草案）
(4, 'clip_20260919_veh07_0011', 1, 1, 1.0),
(4, 'clip_20260919_veh07_0087', 1, 1, 1.0),
(4, 'clip_20260920_veh08_0003', 1, 1, 1.0),
(4, 'clip_20260921_veh08_0072', 2, 2, 1.0),
(4, 'clip_20260925_veh07_0008', 3, 2, 1.5),
-- highway_pilot_prediction v1.0.0
(5, 'clip_20260927_veh09_0040', 1, 1, 1.0),
(5, 'clip_20260927_veh09_0066', 2, 1, 1.0),
-- parking_slot_perception v0.1.0
(6, 'clip_20260926_veh09_0021', 1, 1, 1.0);

-- ------------------------------------------------------------
-- 回填统计字段（以关系表为准）
-- ------------------------------------------------------------
UPDATE dataset_version v
JOIN (
  SELECT vc.version_id,
         COUNT(*)                 AS cnt,
         SUM(vc.split_type = 1)   AS tr,
         SUM(vc.split_type = 2)   AS va,
         SUM(vc.split_type = 3)   AS te,
         SUM(c.duration_sec)      AS dur,
         SUM(c.size_bytes)        AS sz
  FROM version_clip vc
  JOIN clip c ON c.clip_id = vc.clip_id
  GROUP BY vc.version_id
) s ON s.version_id = v.id
SET v.clip_count = s.cnt,
    v.split_train = s.tr, v.split_val = s.va, v.split_test = s.te,
    v.total_duration_sec = s.dur, v.total_size_bytes = s.sz;

UPDATE clip c
SET c.ref_count = (SELECT COUNT(*) FROM version_clip vc WHERE vc.clip_id = c.clip_id);

UPDATE clip c
JOIN (
  SELECT vc.clip_id, MAX(v.created_at) AS t
  FROM version_clip vc
  JOIN dataset_version v ON v.id = vc.version_id
  GROUP BY vc.clip_id
) s ON s.clip_id = c.clip_id
SET c.last_ref_at = s.t;

UPDATE clip SET last_ref_at = '2026-06-20 02:00:00' WHERE clip_id = 'clip_20260605_veh05_0100';

-- ------------------------------------------------------------
-- 9. version_shard（由 version_clip 汇总生成）
-- ------------------------------------------------------------
INSERT INTO version_shard
(version_id, shard_no, shard_name, clip_count, size_bytes, logical_hash, physical_hash,
 cache_path, cache_status, last_read_at, last_verified_at, verify_status)
SELECT
  vc.version_id,
  vc.shard_no,
  CONCAT('shard-', LPAD(vc.shard_no, 6, '0')),
  COUNT(*),
  SUM(c.size_bytes),
  CONCAT('sha256:', SHA2(GROUP_CONCAT(CONCAT(c.clip_id, ':', c.clip_hash) ORDER BY c.clip_id SEPARATOR '\n'), 256)),
  CASE WHEN vc.version_id IN (1,3,4)
       THEN CONCAT('sha256:', SHA2(CONCAT('tar-', vc.version_id, '-', vc.shard_no), 256)) END,
  CASE WHEN vc.version_id IN (1,3,4)
       THEN CONCAT('cpfs://train-cache/', d.name, '/', v.version, '/shard-', LPAD(vc.shard_no, 6, '0'), '.tar') END,
  CASE vc.version_id WHEN 1 THEN 'evicted' WHEN 3 THEN 'ready' WHEN 4 THEN 'warming' ELSE 'none' END,
  CASE vc.version_id WHEN 1 THEN '2026-08-28 16:00:00' WHEN 3 THEN '2026-10-12 09:12:00' END,
  CASE vc.version_id WHEN 1 THEN '2026-09-10 03:00:00' WHEN 3 THEN '2026-10-12 03:00:00' END,
  CASE WHEN vc.version_id IN (1,3) THEN 'ok' ELSE 'unverified' END
FROM version_clip vc
JOIN clip c            ON c.clip_id = vc.clip_id
JOIN dataset_version v ON v.id = vc.version_id
JOIN dataset d         ON d.id = v.dataset_id
GROUP BY vc.version_id, vc.shard_no, v.version, d.name;

-- ------------------------------------------------------------
-- 10. lineage_edge
-- ------------------------------------------------------------
INSERT INTO lineage_edge
(up_type, up_id, down_type, down_id, process_name, process_version, params, run_id, executed_at, executed_by) VALUES
('raw',        'drive_20260918_213045',            'clip',       'batch_20260918_veh07',          '切片', 'slicer v2.1',        '{"clip_len_sec":20}',                         'run_slice_20260919_01', '2026-09-19 02:10:00', 'pipeline.bot'),
('clip',       'batch_20260918_veh07',             'clip',       'batch_20260918_veh07_desens',   '脱敏', 'desensitizer v1.4',  '{"face":true,"plate":true}',                  'run_desens_20260919_01','2026-09-19 02:50:00', 'pipeline.bot'),
('clip',       'batch_20260918_veh07_desens',      'annotation', 'ann_3d_box_v5',                 '标注', 'autolabel v3',       '{"qc_sample_rate":0.1}',                      'run_label_20260922_01', '2026-09-22 15:00:00', 'label.bot'),
('annotation', 'ann_3d_box_v5',                    'version',    'urban_noa_perception:v2.3.1',   '筛选', 'dataset-builder v0.9','{"rule":"cut-in AND qc_pass"}',              'run_build_20261002_01', '2026-10-02 15:00:00', 'zhang.san'),
('clip',       'batch_20260918_veh07_desens',      'version',    'urban_noa_perception:v2.3.1',   '筛选', 'dataset-builder v0.9','{"rule":"cut-in AND qc_pass"}',              'run_build_20261002_01', '2026-10-02 15:00:00', 'zhang.san'),
('version',    'urban_noa_perception:v2.3.0',      'model',      'model_perception_0925',         '训练', 'trainer v1.12',      '{"gpus":64,"epochs":30}',                     'train_8821',            '2026-09-28 03:30:00', 'zhang.san'),
('version',    'urban_noa_perception:v2.3.1',      'model',      'model_perception_1008',         '训练', 'trainer v1.12',      '{"gpus":64,"epochs":30}',                     'train_8902',            '2026-10-04 09:00:00', 'zhang.san'),
('raw',        'drive_20260927_091500',            'clip',       'batch_20260927_veh09',          '切片', 'slicer v2.1',        '{"clip_len_sec":20}',                         'run_slice_20260928_01', '2026-09-28 02:10:00', 'pipeline.bot');

-- ------------------------------------------------------------
-- 11. task_dataset_ref
-- ------------------------------------------------------------
INSERT INTO task_dataset_ref
(task_id, task_type, attempt_no, version_id, manifest_hash, verify_result, verify_detail, verify_cost_ms,
 resume_from, model_artifact_id, started_at, finished_at) VALUES
('train_8790', 'train', 1, 1, (SELECT manifest_hash FROM dataset_version WHERE id = 1), 'pass',
 '{"manifest":"ok","annotation":"ok","calibration":"ok","sample_ratio":0.01,"seed":20260902,"failed_shards":[]}', 38000,
 NULL, 'model_perception_0910', '2026-09-02 09:00:00', '2026-09-08 18:00:00'),
('train_8821', 'train', 1, 2, (SELECT manifest_hash FROM dataset_version WHERE id = 2), 'pass',
 '{"manifest":"ok","annotation":"ok","calibration":"ok","sample_ratio":0.01,"seed":20260925,"failed_shards":[]}', 40000,
 NULL, NULL, '2026-09-25 10:30:41', '2026-09-28 03:20:00'),
('train_8821', 'train', 2, 2, (SELECT manifest_hash FROM dataset_version WHERE id = 2), 'pass',
 '{"manifest":"ok","version_consistent":true,"sample_ratio":0.01,"seed":20260928,"failed_shards":[]}', 12000,
 'shard-000002:offset=412', 'model_perception_0925', '2026-09-28 03:30:00', '2026-09-30 22:00:00'),
('train_8902', 'train', 1, 3, (SELECT manifest_hash FROM dataset_version WHERE id = 3), 'pass',
 '{"manifest":"ok","annotation":"ok","calibration":"ok","sample_ratio":0.01,"seed":20261004,"failed_shards":[]}', 41000,
 NULL, 'model_perception_1008', '2026-10-04 09:00:00', '2026-10-08 20:00:00'),
('train_8915', 'train', 1, 3, CONCAT('sha256:', SHA2('tampered-manifest', 256)), 'fail',
 '{"manifest":"mismatch","expected":"see dataset_version","failed_shards":[]}', 1500,
 NULL, NULL, '2026-10-06 10:30:01', '2026-10-06 10:30:03'),
('eval_5102', 'eval', 1, 3, (SELECT manifest_hash FROM dataset_version WHERE id = 3), 'pass',
 '{"manifest":"ok","annotation":"ok","sample_ratio":0.05,"seed":20261009,"failed_shards":[]}', 22000,
 NULL, NULL, '2026-10-09 14:00:00', '2026-10-09 15:10:00'),
('train_9001', 'train', 1, 5, (SELECT manifest_hash FROM dataset_version WHERE id = 5), 'pass',
 '{"manifest":"ok","annotation":"ok","sample_ratio":0.01,"seed":20261002,"failed_shards":[]}', 9000,
 NULL, 'model_prediction_1005', '2026-10-02 09:00:00', '2026-10-05 12:00:00');

-- ------------------------------------------------------------
-- 12. protection
-- ------------------------------------------------------------
INSERT INTO protection (target_type, target_id, reason_type, reason, protected_until, created_by) VALUES
('version',    '3',                          'release',    '量产模型 model_perception_1008 依赖该版本',     NULL,         'zhang.san'),
('version',    '1',                          'baseline',   'v2.2.0 作为验收基线集，用于新模型回归对比',     NULL,         'zhang.san'),
('clip',       'clip_20260925_veh07_0008',   'incident',   '事故复盘相关数据（工单 INC-2026-0925）',        '2028-09-25', 'compliance.bot'),
('calibration','2',                          'compliance', 'veh07 当前生效标定，追溯留存',                  NULL,         'compliance.bot');

-- ------------------------------------------------------------
-- 13. cleanup_audit
-- ------------------------------------------------------------
INSERT INTO cleanup_audit
(target_type, target_id, action, rule_id, rule_snapshot, size_bytes, recoverable, operator, created_at) VALUES
('clip',    'clip_20260605_veh05_0100',                        'mark',    'R-03', '无任何版本引用且超过 90 天',                    1920000000, 1, 'cleanup.bot', '2026-09-25 02:00:00'),
('clip',    'clip_20260605_veh05_0100',                        'freeze',  'R-03', '标记后进入 7 天冻结期',                          1920000000, 1, 'cleanup.bot', '2026-09-25 02:05:00'),
('cache',   'urban_noa_perception/v2.2.0/shard-000001',        'delete',  'R-05', '缓存分片近 14 天无读取，LRU 淘汰，OSS 为事实源', 4900000000, 0, 'cleanup.bot', '2026-09-12 02:00:00'),
('cache',   'urban_noa_perception/v2.2.0/shard-000002',        'delete',  'R-05', '缓存分片近 14 天无读取，LRU 淘汰，OSS 为事实源', 4890000000, 0, 'cleanup.bot', '2026-09-12 02:01:00'),
('version', 'urban_noa_perception:v2.3.0',                     'mark',    'R-02', '版本已 deprecated，且已由 v2.3.1 替代',          NULL,       1, 'cleanup.bot', '2026-10-05 02:00:00');

-- ------------------------------------------------------------
-- 校验：各表行数
-- ------------------------------------------------------------
SELECT 'dataset' AS tbl, COUNT(*) AS cnt FROM dataset
UNION ALL SELECT 'annotation_set', COUNT(*) FROM annotation_set
UNION ALL SELECT 'dataset_version', COUNT(*) FROM dataset_version
UNION ALL SELECT 'clip', COUNT(*) FROM clip
UNION ALL SELECT 'tag_dict', COUNT(*) FROM tag_dict
UNION ALL SELECT 'clip_tag', COUNT(*) FROM clip_tag
UNION ALL SELECT 'calibration', COUNT(*) FROM calibration
UNION ALL SELECT 'version_clip', COUNT(*) FROM version_clip
UNION ALL SELECT 'version_shard', COUNT(*) FROM version_shard
UNION ALL SELECT 'lineage_edge', COUNT(*) FROM lineage_edge
UNION ALL SELECT 'task_dataset_ref', COUNT(*) FROM task_dataset_ref
UNION ALL SELECT 'protection', COUNT(*) FROM protection
UNION ALL SELECT 'cleanup_audit', COUNT(*) FROM cleanup_audit;
