-- ============================================================
-- 智驾数据集元数据库 DDL
-- 目标库：MySQL 8.0 / PolarDB MySQL
-- 说明：不使用外键约束，引用完整性由应用层和巡检保证
-- ============================================================

CREATE DATABASE IF NOT EXISTS ad_dataset_meta
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE ad_dataset_meta;

-- 重建时按此顺序清理（仅用于测试环境）
DROP TABLE IF EXISTS cleanup_audit;
DROP TABLE IF EXISTS protection;
DROP TABLE IF EXISTS task_dataset_ref;
DROP TABLE IF EXISTS lineage_edge;
DROP TABLE IF EXISTS version_clip;
DROP TABLE IF EXISTS version_shard;
DROP TABLE IF EXISTS clip_tag;
DROP TABLE IF EXISTS tag_dict;
DROP TABLE IF EXISTS calibration;
DROP TABLE IF EXISTS clip;
DROP TABLE IF EXISTS dataset_version;
DROP TABLE IF EXISTS annotation_set;
DROP TABLE IF EXISTS dataset;

-- ------------------------------------------------------------
-- 1. dataset 数据集定义
-- ------------------------------------------------------------
CREATE TABLE dataset (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name            VARCHAR(128)  NOT NULL COMMENT '数据集唯一名，如 urban_noa_perception',
  biz_domain      VARCHAR(64)   NOT NULL COMMENT '业务方向：感知/预测/规划/仿真',
  description     VARCHAR(512)  NULL,
  owner           VARCHAR(64)   NOT NULL COMMENT '负责人',
  security_level  TINYINT       NOT NULL DEFAULT 1 COMMENT '保密级别：1内部 2敏感 3严格',
  acl_group       VARCHAR(128)  NULL COMMENT '权限域/访问组',
  status          TINYINT       NOT NULL DEFAULT 1 COMMENT '1启用 0停用',
  created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by      VARCHAR(64)   NOT NULL,
  updated_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  updated_by      VARCHAR(64)   NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据集定义';

-- ------------------------------------------------------------
-- 2. annotation_set 标注集
-- ------------------------------------------------------------
CREATE TABLE annotation_set (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name              VARCHAR(128)  NOT NULL COMMENT '如 ann_3d_box_v5',
  ann_type          VARCHAR(32)   NOT NULL COMMENT '3d_box/lane/seg/occupancy/trajectory',
  method            VARCHAR(16)   NOT NULL COMMENT 'manual/auto/mixed',
  producer          VARCHAR(128)  NULL COMMENT '标注团队 / 自动标注模型及版本',
  schema_ver        VARCHAR(32)   NOT NULL COMMENT '标注格式版本',
  clip_count        BIGINT        NOT NULL DEFAULT 0,
  qc_pass_rate      DECIMAL(5,2)  NULL,
  oss_path          VARCHAR(512)  NOT NULL,
  content_hash      VARCHAR(80)   NOT NULL COMMENT '标注集整体哈希（按 clip_id 排序拼接）',
  hash_detail_path  VARCHAR(512)  NULL,
  status            VARCHAR(16)   NOT NULL DEFAULT 'draft' COMMENT 'draft/released/deprecated',
  parent_id         BIGINT UNSIGNED NULL COMMENT '上一版标注集',
  created_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by        VARCHAR(64)   NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_name (name),
  KEY idx_type_status (ann_type, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标注集';

-- ------------------------------------------------------------
-- 3. dataset_version 数据集版本
-- ------------------------------------------------------------
CREATE TABLE dataset_version (
  id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  dataset_id          BIGINT UNSIGNED NOT NULL,
  version             VARCHAR(32)   NOT NULL COMMENT '如 v2.3.0',
  major               INT           NOT NULL,
  minor               INT           NOT NULL,
  patch               INT           NOT NULL,
  parent_version_id   BIGINT UNSIGNED NULL COMMENT '父版本',
  status              VARCHAR(16)   NOT NULL DEFAULT 'draft' COMMENT 'draft/released/deprecated/archived',
  deprecate_reason    VARCHAR(512)  NULL COMMENT '作废原因，deprecated 时必填',
  clip_count          BIGINT        NOT NULL DEFAULT 0,
  total_duration_sec  BIGINT        NOT NULL DEFAULT 0,
  total_size_bytes    BIGINT        NOT NULL DEFAULT 0,
  split_train         BIGINT        NOT NULL DEFAULT 0,
  split_val           BIGINT        NOT NULL DEFAULT 0,
  split_test          BIGINT        NOT NULL DEFAULT 0,
  annotation_set_id   BIGINT UNSIGNED NULL COMMENT '引用标注集',
  calibration_policy  VARCHAR(256)  NULL COMMENT '标定引用策略或标定集版本号',
  filter_rule         TEXT          NULL COMMENT '筛选规则快照（SQL/表达式），用于复现',
  tag_distribution    JSON          NULL COMMENT '场景标签分布统计',
  manifest_path       VARCHAR(512)  NOT NULL COMMENT 'OSS 路径',
  manifest_hash       VARCHAR(80)   NOT NULL COMMENT 'sha256:...',
  manifest_signature  VARCHAR(512)  NULL COMMENT '对 manifest_hash 的签名',
  hash_algo           VARCHAR(16)   NOT NULL DEFAULT 'sha256',
  released_at         DATETIME      NULL,
  released_by         VARCHAR(64)   NULL,
  created_at          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by          VARCHAR(64)   NOT NULL,
  updated_at          DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_dataset_version (dataset_id, version),
  KEY idx_status (status),
  KEY idx_parent (parent_version_id),
  KEY idx_released_at (released_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据集版本';

-- ------------------------------------------------------------
-- 4. clip 片段索引
-- ------------------------------------------------------------
CREATE TABLE clip (
  clip_id           VARCHAR(64)   NOT NULL COMMENT '如 clip_20260918_veh07_0032',
  vehicle_id        VARCHAR(32)   NOT NULL,
  collect_date      DATE          NOT NULL,
  city              VARCHAR(32)   NULL,
  start_ts          BIGINT        NOT NULL COMMENT '起始时间戳（毫秒）',
  end_ts            BIGINT        NOT NULL,
  duration_sec      SMALLINT      NOT NULL,
  raw_package_id    VARCHAR(128)  NOT NULL COMMENT '来源原始数据包',
  raw_offset_ms     BIGINT        NULL COMMENT '在原始包中的偏移',
  data_format       VARCHAR(32)   NOT NULL COMMENT '如 mp4+pcd+parquet',
  oss_path          VARCHAR(512)  NOT NULL,
  size_bytes        BIGINT        NOT NULL,
  file_count        INT           NOT NULL,
  clip_hash         VARCHAR(80)   NOT NULL COMMENT '两层计算得到的 clip 级哈希',
  hash_algo         VARCHAR(16)   NOT NULL DEFAULT 'sha256',
  hash_detail_path  VARCHAR(512)  NULL COMMENT 'OSS 上各文件哈希明细清单（不入库）',
  desensitized      TINYINT       NOT NULL DEFAULT 0 COMMENT '是否已脱敏',
  qc_status         VARCHAR(16)   NOT NULL DEFAULT 'pending' COMMENT 'pending/pass/fail',
  storage_tier      VARCHAR(16)   NOT NULL DEFAULT 'standard' COMMENT 'standard/ia/archive',
  ref_count         INT           NOT NULL DEFAULT 0 COMMENT '被版本引用的计数（冗余，巡检校准）',
  last_ref_at       DATETIME      NULL COMMENT '最近一次被版本引用的时间',
  created_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by        VARCHAR(64)   NOT NULL,
  updated_at        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (clip_id),
  KEY idx_vehicle_date (vehicle_id, collect_date),
  KEY idx_city_date (city, collect_date),
  KEY idx_raw_package (raw_package_id),
  KEY idx_hash (clip_hash),
  KEY idx_cleanup (ref_count, last_ref_at, storage_tier)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='clip 索引';

-- ------------------------------------------------------------
-- 5. tag_dict 场景标签字典
-- ------------------------------------------------------------
CREATE TABLE tag_dict (
  id          INT           NOT NULL AUTO_INCREMENT,
  category    VARCHAR(32)   NOT NULL COMMENT '天气/光照/道路/事件/…',
  tag_name    VARCHAR(64)   NOT NULL COMMENT '夜间/雨天/隧道/cut-in/无保护左转',
  description VARCHAR(256)  NULL,
  status      TINYINT       NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uk_tag (category, tag_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='场景标签字典';

-- ------------------------------------------------------------
-- 6. clip_tag clip 与标签关系
-- ------------------------------------------------------------
CREATE TABLE clip_tag (
  clip_id     VARCHAR(64)   NOT NULL,
  tag_id      INT           NOT NULL,
  source      VARCHAR(16)   NOT NULL COMMENT 'manual/rule/model',
  source_ver  VARCHAR(64)   NULL COMMENT '规则或模型版本',
  confidence  DECIMAL(4,3)  NULL COMMENT '置信度 0~1',
  start_ms    INT           NULL COMMENT '事件在 clip 内的起点（可选）',
  end_ms      INT           NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (clip_id, tag_id, source),
  KEY idx_tag_clip (tag_id, clip_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='clip 与标签关系';

-- ------------------------------------------------------------
-- 7. calibration 标定记录
-- ------------------------------------------------------------
CREATE TABLE calibration (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vehicle_id      VARCHAR(32)   NOT NULL,
  calib_version   VARCHAR(32)   NOT NULL COMMENT '如 calib_v3',
  valid_from      DATETIME      NOT NULL,
  valid_to        DATETIME      NULL COMMENT 'NULL 表示当前仍有效',
  sensor_scope    VARCHAR(128)  NULL COMMENT '覆盖传感器范围',
  quality_score   DECIMAL(5,2)  NULL,
  oss_path        VARCHAR(512)  NOT NULL,
  file_hash       VARCHAR(80)   NOT NULL,
  status          VARCHAR(16)   NOT NULL DEFAULT 'valid' COMMENT 'valid/invalid',
  invalid_reason  VARCHAR(512)  NULL COMMENT '标定被判错时记录原因，用于血缘反查',
  created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by      VARCHAR(64)   NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_vehicle_version (vehicle_id, calib_version),
  KEY idx_vehicle_time (vehicle_id, valid_from, valid_to)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标定记录';

-- ------------------------------------------------------------
-- 8. version_shard 版本分片清单
-- ------------------------------------------------------------
CREATE TABLE version_shard (
  version_id        BIGINT UNSIGNED NOT NULL,
  shard_no          INT           NOT NULL COMMENT '分片序号',
  shard_name        VARCHAR(64)   NOT NULL COMMENT '如 shard-000001',
  clip_count        INT           NOT NULL,
  size_bytes        BIGINT        NOT NULL,
  logical_hash      VARCHAR(80)   NOT NULL COMMENT '逻辑哈希：clip_hash 列表的哈希，进入 manifest',
  physical_hash     VARCHAR(80)   NULL COMMENT '物理哈希：打包后 tar 文件字节哈希',
  cache_path        VARCHAR(512)  NULL COMMENT 'CPFS/缓存层路径',
  cache_status      VARCHAR(16)   NOT NULL DEFAULT 'none' COMMENT 'none/warming/ready/evicted',
  last_read_at      DATETIME      NULL COMMENT '最近被训练任务读取时间，用于 LRU 淘汰',
  last_verified_at  DATETIME      NULL COMMENT '最近一次后台校验时间',
  verify_status     VARCHAR(16)   NOT NULL DEFAULT 'unverified' COMMENT 'unverified/ok/failed',
  PRIMARY KEY (version_id, shard_no),
  KEY idx_cache_status (cache_status, last_read_at),
  KEY idx_verify (verify_status, last_verified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='版本分片清单';

-- ------------------------------------------------------------
-- 9. version_clip 版本与 clip 关系（最大表，按 version_id 哈希分区）
-- ------------------------------------------------------------
CREATE TABLE version_clip (
  version_id  BIGINT UNSIGNED NOT NULL,
  clip_id     VARCHAR(64)   NOT NULL,
  split_type  TINYINT       NOT NULL COMMENT '1train 2val 3test',
  shard_no    INT           NOT NULL COMMENT '所属分片',
  weight      FLOAT         NOT NULL DEFAULT 1.0 COMMENT '采样权重',
  PRIMARY KEY (version_id, clip_id),
  KEY idx_clip_version (clip_id, version_id),
  KEY idx_shard (version_id, shard_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='版本与 clip 关系'
PARTITION BY HASH (version_id) PARTITIONS 8;

-- ------------------------------------------------------------
-- 10. lineage_edge 血缘（边表）
-- ------------------------------------------------------------
CREATE TABLE lineage_edge (
  id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  up_type          VARCHAR(16)   NOT NULL COMMENT 'raw/clip/annotation/version/model',
  up_id            VARCHAR(128)  NOT NULL,
  down_type        VARCHAR(16)   NOT NULL,
  down_id          VARCHAR(128)  NOT NULL,
  process_name     VARCHAR(64)   NOT NULL COMMENT '脱敏/切片/标注/筛选/训练',
  process_version  VARCHAR(64)   NULL COMMENT '处理程序版本，如 脱敏程序 v1.4',
  params           JSON          NULL COMMENT '处理参数',
  run_id           VARCHAR(128)  NULL COMMENT '流水线或任务运行 ID',
  executed_at      DATETIME      NOT NULL,
  executed_by      VARCHAR(64)   NULL,
  PRIMARY KEY (id),
  KEY idx_up (up_type, up_id),
  KEY idx_down (down_type, down_id),
  KEY idx_run (run_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='血缘关系（边表）';

-- ------------------------------------------------------------
-- 11. task_dataset_ref 任务引用的数据集版本
-- ------------------------------------------------------------
CREATE TABLE task_dataset_ref (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  task_id            VARCHAR(64)   NOT NULL COMMENT '如 train_8821',
  task_type          VARCHAR(16)   NOT NULL COMMENT 'train/eval/replay',
  attempt_no         INT           NOT NULL DEFAULT 1 COMMENT '第几次尝试（重试/续跑）',
  version_id         BIGINT UNSIGNED NOT NULL,
  manifest_hash      VARCHAR(80)   NOT NULL COMMENT '启动时实际校验到的哈希',
  verify_result      VARCHAR(16)   NOT NULL COMMENT 'pass/fail',
  verify_detail      JSON          NULL COMMENT '各校验项结果、抽检比例、随机种子、失败分片',
  verify_cost_ms     INT           NULL,
  resume_from        VARCHAR(256)  NULL COMMENT '续跑起点（分片/偏移），首次启动为空',
  model_artifact_id  VARCHAR(128)  NULL COMMENT '产出模型 ID',
  started_at         DATETIME      NOT NULL,
  finished_at        DATETIME      NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_task_attempt (task_id, attempt_no),
  KEY idx_version (version_id, started_at),
  KEY idx_model (model_artifact_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='任务引用的数据集版本';

-- ------------------------------------------------------------
-- 12. protection 保护标记
-- ------------------------------------------------------------
CREATE TABLE protection (
  id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  target_type      VARCHAR(16)   NOT NULL COMMENT 'version/clip/annotation_set/calibration',
  target_id        VARCHAR(128)  NOT NULL,
  reason_type      VARCHAR(32)   NOT NULL COMMENT 'release/baseline/compliance/incident',
  reason           VARCHAR(512)  NOT NULL,
  protected_until  DATE          NULL COMMENT 'NULL 表示长期保护',
  created_at       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by       VARCHAR(64)   NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_target (target_type, target_id, reason_type),
  KEY idx_until (protected_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='保护标记，清理程序必须跳过';

-- ------------------------------------------------------------
-- 13. cleanup_audit 清理审计（只追加）
-- ------------------------------------------------------------
CREATE TABLE cleanup_audit (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  target_type    VARCHAR(16)   NOT NULL,
  target_id      VARCHAR(128)  NOT NULL,
  action         VARCHAR(16)   NOT NULL COMMENT 'mark/freeze/archive/delete/restore',
  rule_id        VARCHAR(32)   NOT NULL COMMENT '触发规则，如 R-07',
  rule_snapshot  VARCHAR(512)  NULL COMMENT '规则内容快照',
  size_bytes     BIGINT        NULL COMMENT '释放或涉及的容量',
  recoverable    TINYINT       NOT NULL DEFAULT 0,
  operator       VARCHAR(64)   NOT NULL COMMENT '系统或人员',
  created_at     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_target (target_type, target_id),
  KEY idx_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='清理审计，只追加';
